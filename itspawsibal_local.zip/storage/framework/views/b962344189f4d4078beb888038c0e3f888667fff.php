

<?php $__env->startSection('title', 'Species'); ?>

<?php $__env->startSection('navbar'); ?>
##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
<?php echo $__env->make('species/sliderCategoriesEndangered', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="container">
        <h1 data-aos="fade-left" style="margin-top:50px;margin-left: 50px; text-align: justify;">"Want to see how detrimental the busfires have affected these species?"</h1>
        <div class="drop-down-wrapper" style="margin-bottom: 100px;">
          <select class="btn btn-success state-dropdown" value="all">
            <option value="all">Select the State you want to view.</option>
            <option value="Victoria">Victoria</option>
            <option value="New South Wales">New South Wales</option>
          </select>

          <select class="btn btn-success species-dropdown" value="all">
            <option value="all">Select the Species you want to view.</option>
            <option value="Brush-tailed Rock-wallaby">Brush-tailed Rock-wallaby</option>
            <option value="Broad-Toothed Rat">Broad-Toothed Rat</option>
            <option value="Great Glider">Great Glider</option>
          </select>

          <h2>Selected Nothing</h2>

          <input type="hidden" id="final-val" state-value="all" species-value="all">
        </div>
        <div id="map" style="margin-bottom: 200px;"></div>

      </div>

  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('scripts'); ?>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\itspawsibal_local\resources\views/species/try.blade.php ENDPATH**/ ?>