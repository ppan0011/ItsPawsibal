<?php $__env->startSection('title', 'Species'); ?>

<?php $__env->startSection('navbar'); ?>
##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
<?php echo $__env->make('species/sliderCategoriesEndangered', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="stats">
          <h1 data-aos="zoom-in-left" data-aos-duration="2500"> Do you know ?</h1>
      </div>
      <div data-aos="fade-left" data-aos-duration="2500" class="stats-details">
          <h1 style="margin-top:50px;margin-left: 50px; text-align: justify;">"More than 480 million mammals, birds and reptiles have been affected because of the drastic bushfire season 2019-2020."</h1>
          <img src="<?php echo e(asset('images/CategoryImage3.jpg')); ?>" style="width: 700px;">
      </div>
      <div data-aos="fade-right" data-aos-duration="2500" class="stats-details-right">
          <h1><div id="counter">
              <div style="width: 350px;">
                <p class="counter-value" data-count="7"></p>
                <h3>Species became extinct</h3>
              </div>
              <div style="width: 500px;"><p class="counter-value" data-count="17"></p>
                <h3>Species became extinct</h3></div>
              <div><p class="counter-value" data-count="601704"></p>
                <h3>Hectares have been burnt so far.</h3></div>
              </div> 
          </h1>
      </div>
      <div data-aos="fade-left" data-aos-duration="2500" class="stats-details">
          <h1 style="margin-top:50px;margin-left: 50px; text-align: justify;">"Want to see how detrimental the busfires have affected these species?"</h1>
          <div><button type="button" class="btn btn-success button-stats" onclick="myFunction()" style="margin-top:80px; margin-bottom: 20px;margin-left: 50px; width:147px; text-align: justify;">Click here to know</button></div>
          <img src="<?php echo e(asset('images/PotorooImage.jpg')); ?>">
      </div>
      <div class="container">
        <h1 data-aos="fade-left" style="margin-top:50px;margin-left: 50px; text-align: justify;">"Want to see how detrimental the busfires have affected these species?"</h1>
        <div class="drop-down-wrapper">
          <select>
            <option value="">Select the State you want to view.</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>
          <h2>Selected Nothing</h2>
        </div>
        <!-- <div id="map"></div>
            <script type="text/javascript" src="<?php echo e(asset('js./maps.js')); ?>"></script>
            <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB6NqKaeopGxcPNpfE8jEIF04J8Aa1nVT8&callback=initMap">
          </script> -->
      </div>

  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('scripts'); ?>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\itspawsibal_local\resources\views/species/speciesLandingPage.blade.php ENDPATH**/ ?>