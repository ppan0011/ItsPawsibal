<header class="header-area overlay">
    <nav class="navbar navbar-expand-md navbar-dark">
        <div class="container">
            <div>
                <a href=""><img class="navbar-img" src="<?php echo e(asset('logo.png')); ?>" /></a>         
                <a href="" class="navbar-brand">It's Pawsibal</a>
            </div>

            <span class="navbar-toggler collapsed" data-toggle="collapse" data-target="#main-nav">   
                <i class="fa fa-angle-down"></i>
            </span>
            
            <div id="main-nav" class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                    <!-- <li><a href="#" class="nav-item nav-link active">Home</a></li>
                    <li><a href="#" class="nav-item nav-link">About Us</a></li>
                    <li class="dropdown">
                        <a href="#" class="nav-item nav-link" data-toggle="dropdown">Services</a>
                        <div class="dropdown-menu">
                            <a href="#" class="dropdown-item">Dropdown Item 1</a>
                            <a href="#" class="dropdown-item">Dropdown Item 2</a>
                            <a href="#" class="dropdown-item">Dropdown Item 3</a>
                        </div>
                    </li> -->
                </ul>
            </div>
        </div>
    </nav>
</header><?php /**PATH D:\xampp\htdocs\itspawsibal_local\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>